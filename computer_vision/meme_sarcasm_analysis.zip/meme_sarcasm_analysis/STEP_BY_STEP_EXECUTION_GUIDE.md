# 🚀 Step-by-Step Execution Guide

## Complete Walkthrough for Running the Project from Zero

---

## PREREQUISITES

Make sure you have:
- Python 3.9 or higher installed
- pip package manager
- ~2 GB free disk space
- (Optional) NVIDIA GPU + CUDA for faster training

---

## STEP 1: Clone the Repository

```bash
git clone https://github.com/YOUR_USERNAME/meme_sarcasm_analysis.git
cd meme_sarcasm_analysis
```

---

## STEP 2: Create a Virtual Environment

```bash
# Create virtual environment
python -m venv venv

# Activate it
# On Linux/macOS:
source venv/bin/activate
# On Windows:
venv\Scripts\activate
```

---

## STEP 3: Install Dependencies

```bash
pip install -r requirements.txt
```

For CLIP support (optional, requires more disk space):
```bash
pip install open-clip-torch
```

---

## STEP 4: Generate the Sample Dataset

```bash
python main.py setup
```

**What this does:**
- Creates `data/sample_dataset/images/` with 200 synthetic meme PNG images
- Creates `data/sample_dataset/metadata.json` with labels and text
- Creates `data/sample_dataset/metadata.csv` (same data in CSV format)

**Expected output:**
```
[SampleGen] Created 200 samples in data/sample_dataset
  Sarcastic    : 100
  Non-sarcastic: 100
```

---

## STEP 5: Run Exploratory Data Analysis (Optional)

Open Jupyter notebook:
```bash
jupyter notebook notebooks/EDA.ipynb
```

Or run preprocessing notebook:
```bash
jupyter notebook notebooks/preprocessing.ipynb
```

---

## STEP 6: Train the Models

### Option A: Train all three models at once
```bash
python main.py train --model all --epochs 10 --batch_size 16
```

### Option B: Train one model at a time
```bash
# Model 1: CNN + LSTM
python main.py train --model cnn_lstm --epochs 15 --batch_size 32

# Model 2: CLIP-based
python main.py train --model clip --epochs 10 --batch_size 16

# Model 3: VisualBERT Lite
python main.py train --model vbert --epochs 10 --batch_size 8
```

### Option C: Force CPU (no GPU)
```bash
python main.py train --model all --epochs 10 --no_gpu
```

### Option D: Use full MMSD 2.0 dataset (after downloading)
```bash
python main.py train --model all --epochs 20 --use_mmsd2
```

**Training output example:**
```
[CNN_LSTM] Epoch   1/10 | Train Loss=0.7124 Acc=0.5312 | Val Loss=0.7001 Acc=0.5429
[CNN_LSTM] Epoch   2/10 | Train Loss=0.6891 Acc=0.5742 | Val Loss=0.6812 Acc=0.5857
...
[CNN_LSTM] DONE | Acc=0.7167 | F1=0.7060 | Time=3m 12.4s
Checkpoint saved → outputs/checkpoints/cnn_lstm_best.pt
```

---

## STEP 7: Evaluate All Models

```bash
python main.py evaluate --model all
```

**Expected output:**
```
Model                     Acc      Prec     Rec      F1       Params
═══════════════════════════════════════════════════════════════════════
CNN_LSTM                  0.7167   0.7032   0.7167   0.7060   12,100,000
CLIP                      0.7400   0.7351   0.7400   0.7373   11,800,000
VisualBERT_Lite           0.7733   0.7765   0.7733   0.7727   22,400,000
═══════════════════════════════════════════════════════════════════════
```

---

## STEP 8: Run Demo Inference

```bash
# Using sample dataset (auto-selects a sample image)
python main.py demo

# Using your own meme image + caption
python main.py demo --image path/to/meme.jpg --text "Oh sure, traffic is lovely today"
```

**Expected output:**
```
══════════════════════════════════════════════
  MEME SARCASM DETECTION – DEMO
══════════════════════════════════════════════
Image : data/sample_dataset/images/sample_0042_label1.png
Text  : Oh sure, Mondays are WONDERFUL
True  : Sarcastic
────────────────────────────────────────
  Not Sarcastic : 0.1832
  Sarcastic     : 0.8168
  Prediction    : SARCASTIC 🎭
────────────────────────────────────────
```

---

## STEP 9: View Results

All outputs are saved automatically:

```
outputs/
├── results.csv                          ← Model comparison table
├── graphs/
│   ├── cnn_lstm_training_curves.png
│   ├── clip_training_curves.png
│   ├── visualbert_lite_training_curves.png
│   ├── model_comparison_accuracy.png
│   ├── model_comparison_f1.png
│   ├── model_comparison_precision.png
│   └── model_comparison_recall.png
└── confusion_matrix/
    ├── cnn_lstm_confusion_matrix.png
    ├── clip_confusion_matrix.png
    └── visualbert_lite_confusion_matrix.png
```

---

## STEP 10: Download MMSD 2.0 (Optional – Full Experiment)

1. Visit: https://github.com/JoeYing1019/MMSD2.0
2. Download the dataset
3. Place files:
   ```
   data/raw/MMSD2/
     ├── images/     ← meme images
     ├── train.json
     ├── val.json
     └── test.json
   ```
4. Preprocess:
   ```bash
   python src/preprocessing.py --preprocess_mmsd2
   ```
5. Train with full dataset:
   ```bash
   python main.py train --model all --epochs 20 --batch_size 32 --use_mmsd2
   ```

---

## TROUBLESHOOTING

| Issue | Solution |
|-------|----------|
| `ModuleNotFoundError: torch` | Run `pip install -r requirements.txt` |
| `FileNotFoundError: metadata.json` | Run `python main.py setup` first |
| Out of memory (GPU) | Use `--no_gpu` flag or reduce `--batch_size` |
| Slow training | Normal on CPU; reduce `--epochs` to 3 for quick test |
| `open_clip` not found | Install with `pip install open-clip-torch` or proceed without (fallback used) |
| Notebook kernel not found | Run `python -m ipykernel install --user` |

---

## QUICK START (Single Command)

If you just want to see everything work end-to-end:

```bash
python main.py setup && \
python main.py train --model all --epochs 3 --batch_size 8 --no_gpu && \
python main.py evaluate --model all
```

Expected time on CPU: ~10–15 minutes for 3 epochs of all 3 models on the sample dataset.

---

*For detailed architecture information, see report/final_report.md or report/final_report.docx*
